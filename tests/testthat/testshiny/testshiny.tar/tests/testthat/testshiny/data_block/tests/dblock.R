app <- ShinyDriver$new("../")
app$snapshotInit("dblock")

app$setInputs(now_tab_main = "Parameters")
app$setInputs(`ui_plot_tune-adaptive_txt_size` = FALSE)
app$setInputs(`ui_plot_tune-txt_size` = 6)
app$setInputs(`ui_plot_tune-txt_alpha` = 0.1)
app$setInputs(now_tab_main = "Data Block")
app$setInputs(`ui_data_block-direction_text` = FALSE)
app$snapshot()
app$setInputs(`ui_data_block-block_boundary` = TRUE)
app$snapshot()
app$setInputs(`ui_data_block-block_boundary` = FALSE)
app$setInputs(`ui_data_block-dat_att_boundary` = TRUE)
app$snapshot()

## Interrupt shinyProcess so covr::save_trace can execute onExit
p <- app$.__enclos_env__$private$shinyProcess
p$interrupt()
p$wait()